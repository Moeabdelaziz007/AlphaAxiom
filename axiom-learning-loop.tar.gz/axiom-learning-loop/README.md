# AXIOM Learning Loop System

## 🎯 Overview

نظام **Self-Learning Data Loop** هو نظام ذكي يحول كل إشارة تداول إلى بيانات تدريب، يتتبع النتائج الفعلية، ويحسب الدقة، ويحسن نفسه تلقائيًا. هذا هو **الحصن التنافسي** الذي لا يمكن لأحد محاكاته.

## 📐 Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    AXIOM LEARNING LOOP                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌──────────┐    ┌──────────────┐    ┌───────────────┐    │
│   │  SIGNAL  │───▶│   CAPTURE    │───▶│  signal_events │    │
│   │ Generated│    │   (D1 Insert)│    │     (D1)       │    │
│   └──────────┘    └──────────────┘    └───────────────┘    │
│                                              │              │
│                                              ▼              │
│   ┌──────────┐    ┌──────────────┐    ┌───────────────┐    │
│   │  CRON    │───▶│   TRACKER    │───▶│signal_outcomes │    │
│   │ (Hourly) │    │ (Fetch Price)│    │     (D1)       │    │
│   └──────────┘    └──────────────┘    └───────────────┘    │
│                                              │              │
│                                              ▼              │
│   ┌──────────┐    ┌──────────────┐    ┌───────────────┐    │
│   │  CRON    │───▶│  AGGREGATOR  │───▶│learning_metrics│    │
│   │ (Daily)  │    │ (Calculate)  │    │     (D1)       │    │
│   └──────────┘    └──────────────┘    └───────────────┘    │
│                                              │              │
│                                              ▼              │
│   ┌──────────┐    ┌──────────────┐    ┌───────────────┐    │
│   │  CRON    │───▶│  OPTIMIZER   │───▶│  KV: weights   │    │
│   │ (Weekly) │    │ (ML Adjust)  │    │  (Updated)     │    │
│   └──────────┘    └──────────────┘    └───────────────┘    │
│                                              │              │
│                                              ▼              │
│                        ┌──────────────────────────┐        │
│                        │  SignalSynthesizer       │        │
│                        │  (Uses New Weights)      │        │
│                        └──────────────────────────┘        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🏗️ Components

### 1. Outcome Tracker (Hourly Cron)

يتتبع ما حدث لكل إشارة بعد 1 ساعة، 4 ساعات، 24 ساعة.

**الميزات:**
- يجمع الإشارات المعلقة كل ساعة
- يستخرج الأسعار الحالية من APIs (Bybit, Finage)
- يحسب العوائد والدقة
- يخزن النتائج في جدول `signal_outcomes`
- يتعامل مع حالات الخطأ والأسواق المغلقة

**التكرار:** كل ساعة (0 * * * *)

### 2. Metrics Aggregator (Daily)

يحسب المقاييس الدقيقة يوميًا ويولد تقارير Telegram.

**الميزات:**
- يحسب الدقة لكل رمز وإتجاه
- يحسب متوسط العوائد والحد الأقصى والحد الأدنى
- يولد تقارير Telegram اليومية
- يخزن المقاييس في جدول `learning_metrics`

**التكرار:** يوميًا عند منتصف الليل UTC (0 0 * * *)

### 3. Weight Optimizer (Weekly)

يحلل العوامل الأداء ويحسن الأوزان تلقائيًا.

**الميزات:**
- يحلل أداء العوامل (momentum, RSI, sentiment, volume, volatility)
- يحسب الأوزان المثلى بناءً على الدقة
- يخزن الأوزان الجديدة في KV مع سجل الإصدارات
- يرسل تقارير التحسين إلى Telegram
- يطبق ضوابط السلامة (حد أقصى 20% تغيير، حد أدنى 5% وزن)

**التكرار:** أسبوعيًا يوم الأحد عند منتصف الليل UTC (0 0 * * 0)

### 4. API Endpoints

واجهات برمجية لاسترداد المقاييس والأوزان والتقارير.

**النهايات:**
- `GET /api/mcp/learning/metrics` - إحصائيات الدقة
- `GET /api/mcp/learning/weights` - الأوزان الحالية
- `GET /api/mcp/learning/weight-history` - سجل الأوزان
- `GET /api/mcp/learning/report` - آخر تقرير
- `GET /api/mcp/learning/stats` - إحصائيات النظام
- `GET /api/mcp/learning/top-performers` - أفضل الأداء
- `GET /api/mcp/learning/worst-performers` - أسوأ الأداء
- `GET /api/mcp/learning/monitoring` - مقاييس المراقبة

## 🗄️ Database Schema

### جداول D1

1. **signal_events** - تخزين الإشارات الرئيسية
2. **signal_outcomes** - تتبع نتائج الإشارات
3. **learning_metrics** - إحصائيات الأداء اليومية
4. **weight_history** - تتبع تغييرات الأوزان
5. **system_monitoring** - مراقبة صحة النظام
6. **telegram_reports** - تخزين تقارير Telegram
7. **api_audit_log** - تسجيل وصول API

## 🚀 Installation & Deployment

### المتطلبات
- Cloudflare Account
- Cloudflare Workers
- D1 Database
- KV Namespace
- wrangler CLI

### الإعداد

1. **إنشاء D1 Database:**
```bash
wrangler d1 create axiom-learning-db
```

2. **تطبيق بنية قاعدة البيانات:**
```bash
wrangler d1 execute axiom-learning-db --file=./schema.sql
```

3. **إنشاء KV Namespace:**
```bash
wrangler kv:namespace create "AXIOM_KV"
```

4. **نشر Outcome Tracker:**
```bash
cd outcome-tracker
wrangler deploy
```

5. **نشر Metrics Aggregator:**
```bash
cd metrics-aggregator
wrangler deploy
```

6. **نشر Weight Optimizer:**
```bash
cd weight-optimizer
wrangler deploy
```

7. **نشر API Endpoints:**
```bash
cd api-endpoints
wrangler deploy
```

### تكوين المتغيرات

```toml
[[d1_databases]]
binding = "DB"
database_name = "axiom-learning-db"
database_id = "YOUR_D1_DATABASE_ID"

[[kv_namespaces]]
binding = "KV"
namespace_id = "YOUR_KV_NAMESPACE_ID"
```

### تكوين Telegram (اختياري)

```bash
wrangler kv:key put TELEGRAM_BOT_TOKEN "YOUR_BOT_TOKEN"
wrangler kv:key put TELEGRAM_CHAT_ID "YOUR_CHAT_ID"
```

## 🔐 Security & Safeguards

### ضوابط الأوزان
- **حد أقصى للتغيير:** 20% لكل عامل في الأسبوع
- **حد أدنى للوزن:** 5% (لا يذهب أي عامل إلى الصفر)
- **الاسترجاع التلقائي:** إذا انخفضت الدقة 10%+

### سلامة البيانات
- **Checksum** على كتابات D1
- **نسخ احتياطي** إلى R2 أسبوعيًا
- **تسجيل الأخطاء** تفصيلي

### المراقبة
- **تنبيه** إذا لم يتم تسجيل إشارات لمدة ساعة
- **تنبيه** إذا انخفضت الدقة تحت 45%
- **سجل المراقبة** في قاعدة البيانات

## 📊 Expected Results

بعد 30 يومًا:
- ✅ 10,000+ إشارة مع النتائج
- ✅ مقاييس الدقة المثبتة لكل أصل/إتجاه
- ✅ أوزان محسنة ذاتيًا تزيد الربحية
- ✅ مجموعة بيانات خاصة أكثر قيمة من الكود نفسه

## 📈 Success Criteria

- ✅ تتبع 100% من نتائج الإشارات تلقائيًا
- ✅ حساب الدقة خلال 24 ساعة من كل إشارة
- ✅ توليد تقارير الأداء اليومية
- ✅ تحسين الأوزان أسبوعيًا بدون تدخل بشري
- ✅ تحسين قابل للقياس في الدقة على مدى 30 يومًا

## 💎 The Moat

هذا النظام يخلق **حصنًا تنافسيًا لا يمكن تكراره**:
- لا أحد لديه بيانات الأداء الخاصة بك
- كل يوم، الذكاء الاصطناعي يصبح أذكى
- الدقة التاريخية تثبت أن الاستراتيجية تعمل
- يمكنك إظهار نتائج الاختبار الخلفي الحقيقية للمستثمرين

هذا ليس مجرد كود. هذا هو **DNA** صندوق الاستثمار الخاص بك.

## 📝 Testing

```bash
cd tests
# Run integration tests
node integration-test.js
```

## 📚 Documentation

- `schema.sql` - بنية قاعدة البيانات
- `outcome-tracker/` - Outcome Tracker implementation
- `metrics-aggregator/` - Metrics Aggregator implementation
- `weight-optimizer/` - Weight Optimizer implementation
- `api-endpoints/` - API Endpoints implementation
- `tests/` - Integration tests

## 🐛 Troubleshooting

### مشكلة: لا يتم تتبع الإشارات
**الحل:** تحقق من أن Cron Job يعمل، وتأكد من وجود إشارات قديمة أكثر من ساعة.

### مشكلة: لا تصل تقارير Telegram
**الحل:** تحقق من أن `TELEGRAM_BOT_TOKEN` و `TELEGRAM_CHAT_ID` مضبوطين في KV.

### مشكلة: الأوزان لا تتغير
**الحل:** تحقق من أن Weight Optimizer يعمل أسبوعيًا، وتأكد من وجود بيانات كافية (30 يومًا).

## 📞 Support

للحصول على مساعدة، تفضل بزيارة:
- [Cloudflare Workers Documentation](https://developers.cloudflare.com/workers/)
- [D1 Database Documentation](https://developers.cloudflare.com/d1/)

## 📄 License

MIT License

---

**تم إنشاء هذا النظام بواسطة AXIOM Trading System**
